resource_manifest_version '44febabe-d386-4d18-afbe-5e627fkhf453'
this_is_a_map 'yes'

data_file 'DLC_ITYP_REQUEST' 'stream/patoche_elevatorb1.ytyp'

client_script '@bigswagger/59642.lua'
files { "stream/interiorproxies.meta" }

file 'interiorproxies.meta'
data_file 'INTERIOR_PROXY_ORDER_FILE' 'interiorproxies.meta'
data_file 'DLC_ITYP_REQUEST' 'stream/lafa2k_modernhouse.ytyp'
data_file 'DLC_ITYP_REQUEST' 'md_weedshop_mlo.ytyp'
data_file('DLC_ITYP_REQUEST')('stream/prison_props.ytyp')

data_file "INTERIOR_PROXY_ORDER_FILE" "interiorproxies.meta"

data_file 'INTERIOR_PROXY_ORDER_FILE' 'interiorproxies.meta'
