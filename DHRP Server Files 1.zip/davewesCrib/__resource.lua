fx_version 'bodacious'
game 'gta5'

description 'did2'


file 'interiorproxies.meta'
data_file 'INTERIOR_PROXY_ORDER_FILE' 'interiorproxies.meta'

this_is_a_map 'yes'