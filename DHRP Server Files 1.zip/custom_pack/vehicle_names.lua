function AddTextEntry(key, value)
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)
end

Citizen.CreateThread(function()

    AddTextEntry("gameName", "what u want it called")  --1
    AddTextEntry("gameName", "how u will see it in garage menu") --2

end)
