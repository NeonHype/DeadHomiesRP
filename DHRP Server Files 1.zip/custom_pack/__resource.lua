resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'
client_script 'vehicle_names.lua'

data_file 'CARCOLS_FILE' '350z_data/carcols.meta'
data_file 'HANDLING_FILE' '350z_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '350z_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '350z_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '350z_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'civic_data/carcols.meta'
data_file 'HANDLING_FILE' 'civic_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'civic_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'civic_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'civic_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'e46_data/carcols.meta'
data_file 'HANDLING_FILE' 'e46_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'e46_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'e46_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'e46_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'evo_data/carcols.meta'
data_file 'HANDLING_FILE' 'evo_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'evo_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'evo_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'evo_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'evoz_data/carcols.meta'
data_file 'HANDLING_FILE' 'evoz_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'evoz_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'evoz_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'evoz_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'faf_data/carcols.meta'
data_file 'HANDLING_FILE' 'faf_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'faf_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'faf_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'faf_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'golf_data/carcols.meta'
data_file 'HANDLING_FILE' 'golf_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'golf_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'golf_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'golf_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'gt86_data/carcols.meta'
data_file 'HANDLING_FILE' 'gt86_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'gt86_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'gt86_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gt86_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'm3_data/carcols.meta'
data_file 'HANDLING_FILE' 'm3_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'm3_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'm3_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'm3_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'rx7_data/carcols.meta'
data_file 'HANDLING_FILE' 'rx7_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'rx7_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'rx7_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'rx7_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'silvia_data/carcols.meta'
data_file 'HANDLING_FILE' 'silvia_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'silvia_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'silvia_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'silvia_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'skyline_data/carcols.meta'
data_file 'HANDLING_FILE' 'skyline_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'skyline_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'skyline_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'skyline_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'skyline1_data/carcols.meta'
data_file 'HANDLING_FILE' 'skyline1_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'skyline1_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'skyline1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'skyline1_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'sti_data/carcols.meta'
data_file 'HANDLING_FILE' 'sti_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'sti_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'sti_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sti_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'supra_data/carcols.meta'
data_file 'HANDLING_FILE' 'supra_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'supra_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'supra_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'supra_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'supra1_data/carcols.meta'
data_file 'HANDLING_FILE' 'supra1_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'supra1_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'supra1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'supra1_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'zen_data/carcols.meta'
data_file 'HANDLING_FILE' 'zen_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'zen_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'zen_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'zen_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'bad_data/carcols.meta'
data_file 'HANDLING_FILE' 'bad_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'bad_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'bad_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'bad_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'clean_data/carcols.meta'
data_file 'HANDLING_FILE' 'clean_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'clean_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'clean_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'clean_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'drift_data/carcols.meta'
data_file 'HANDLING_FILE' 'drift_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'drift_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'drift_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'drift_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'fast_data/carcols.meta'
data_file 'HANDLING_FILE' 'fast_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'fast_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'fast_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'fast_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'power_data/carcols.meta'
data_file 'HANDLING_FILE' 'power_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'power_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'power_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'power_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'rocket_data/carcols.meta'
data_file 'HANDLING_FILE' 'rocket_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'rocket_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'rocket_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'rocket_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'nissan_data/carcols.meta'
data_file 'HANDLING_FILE' 'nissan_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'nissan_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'nissan_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'nissan_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'camaro_data/carcols.meta'
data_file 'HANDLING_FILE' 'camaro_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'camaro_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'camaro_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'camaro_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'gtr50_data/carcols.meta'
data_file 'HANDLING_FILE' 'gtr50_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'gtr50_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'gtr50_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gtr50_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'i8_data/carcols.meta'
data_file 'HANDLING_FILE' 'i8_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'i8_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'i8_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'i8_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'lfa_data/carcols.meta'
data_file 'HANDLING_FILE' 'lfa_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'lfa_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'lfa_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'lfa_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'supra3_data/carcols.meta'
data_file 'HANDLING_FILE' 'supra3_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'supra3_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'supra3_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'supra3_data/carvariations.meta'

data_file 'CARCOLS_FILE' '350p_data/carcols.meta'
data_file 'HANDLING_FILE' '350p_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '350p_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '350p_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '350p_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'hevo_data/carcols.meta'
data_file 'HANDLING_FILE' 'hevo_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'hevo_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'hevo_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'hevo_data/carvariations.meta'

data_file 'CARCOLS_FILE' '1969_data/carcols.meta'
data_file 'HANDLING_FILE' '1969_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '1969_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '1969_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '1969_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'impreza_data/carcols.meta'
data_file 'HANDLING_FILE' 'impreza_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'impreza_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'impreza_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'impreza_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'annis_data/carcols.meta'
data_file 'HANDLING_FILE' 'annis_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'annis_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'annis_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'annis_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'silv_data/carcols.meta'
data_file 'HANDLING_FILE' 'silv_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'silv_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'silv_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'silv_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'ford_data/carcols.meta'
data_file 'HANDLING_FILE' 'ford_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'ford_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'ford_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'ford_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'lc500_data/carcols.meta'
data_file 'HANDLING_FILE' 'lc500_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'lc500_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'lc500_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'lc500_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'gpr_data/carcols.meta'
data_file 'HANDLING_FILE' 'gpr_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'gpr_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'gpr_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gpr_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'cook_data/carcols.meta'
data_file 'HANDLING_FILE' 'cook_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'cook_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'cook_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'cook_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'mor_data/carcols.meta'
data_file 'HANDLING_FILE' 'mor_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'mor_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'mor_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'mor_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'srt_data/carcols.meta'
data_file 'HANDLING_FILE' 'srt_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'srt_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'srt_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'srt_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'pol_data/carcols.meta'
data_file 'HANDLING_FILE' 'pol_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'pol_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'pol_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pol_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'jeep_data/carcols.meta'
data_file 'HANDLING_FILE' 'jeep_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'jeep_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'jeep_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'jeep_data/carvariations.meta'

data_file 'CARCOLS_FILE' '240_data/carcols.meta'
data_file 'HANDLING_FILE' '240_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '240_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '240_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '240_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'i8d_data/carcols.meta'
data_file 'HANDLING_FILE' 'i8d_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'i8d_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'i8d_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'i8d_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'g65_data/carcols.meta'
data_file 'HANDLING_FILE' 'g65_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'g65_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'g65_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'g65_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'gtr12_data/carcols.meta'
data_file 'HANDLING_FILE' 'gtr12_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'gtr12_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'gtr12_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gtr12_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'draft_data/carcols.meta'
data_file 'HANDLING_FILE' 'draft_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'draft_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'draft_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'draft_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'singer_data/carcols.meta'
data_file 'HANDLING_FILE' 'singer_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'singer_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'singer_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'singer_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'charger_data/carcols.meta'
data_file 'HANDLING_FILE' 'charger_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'charger_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'charger_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'charger_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'c8_data/carcols.meta'
data_file 'HANDLING_FILE' 'c8_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'c8_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'c8_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'c8_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'sky_data/carcols.meta'
data_file 'HANDLING_FILE' 'sky_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'sky_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'sky_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sky_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'pw_data/carcols.meta'
data_file 'HANDLING_FILE' 'pw_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'pw_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'pw_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pw_data/carvariations.meta'

data_file 'HANDLING_FILE' 'm5_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'm5_data/vehicles.meta'
data_file 'CARCOLS_FILE' 'm5_data/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'm5_data/carvariations.meta'

data_file 'HANDLING_FILE' 'rs3_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'rs3_data/vehicles.meta'
data_file 'CARCOLS_FILE' 'rs3_data/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'rs3_data/carvariations.meta'

data_file 'HANDLING_FILE' 'rs6_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'rs6_data/vehicles.meta'
data_file 'CARCOLS_FILE' 'rs6_data/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'rs6_data/carvariations.meta'

data_file 'HANDLING_FILE' 'bently_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'bently_data/vehicles.meta'
data_file 'CARCOLS_FILE' 'bently_data/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'bently_data/carvariations.meta'

data_file 'HANDLING_FILE' 'golf5_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'golf5_data/vehicles.meta'
data_file 'CARCOLS_FILE' 'golf5_data/carcols.meta'
data_file 'VEHICLE_VARIATION_FILE' 'golf5_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'charger1_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'charger1_data/carcols.meta'
data_file 'HANDLING_FILE' 'charger1_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'charger1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'charger1_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'explorer_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'explorer_data/carcols.meta'
data_file 'HANDLING_FILE' 'explorer_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'explorer_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'explorer_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'tahoe_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'tahoe_data/carcols.meta'
data_file 'HANDLING_FILE' 'tahoe_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'tahoe_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'tahoe_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'testercar_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'testercar_data/carcols.meta'
data_file 'HANDLING_FILE' 'testercar_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'testercar_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'testercar_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'semaf450_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'semaf450_data/carcols.meta'
data_file 'HANDLING_FILE' 'semaf450_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'semaf450_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'semaf450_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'RR_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'RR_data/carcols.meta'
data_file 'HANDLING_FILE' 'RR_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'RR_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'RR_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gt861_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gt861_data/carcols.meta'
data_file 'HANDLING_FILE' 'gt861_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gt861_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gt861_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'lexus_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'lexus_data/carcols.meta'
data_file 'HANDLING_FILE' 'lexus_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'lexus_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'lexus_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'faf1_data/carcols.meta'
data_file 'HANDLING_FILE' 'faf1_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'faf1_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'faf1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'faf1_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'rx71_data/carcols.meta'
data_file 'HANDLING_FILE' 'rx71_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'rx71_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'rx71_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'rx71_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'AT_data/carcols.meta'
data_file 'HANDLING_FILE' 'AT_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'AT_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'AT_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'AT_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'cori_data/carcols.meta'
data_file 'HANDLING_FILE' 'cori_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'cori_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'cori_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'cori_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'tool_data/carcols.meta'
data_file 'HANDLING_FILE' 'tool_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'tool_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'tool_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'tool_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'jeepb_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'jeepb_data/carcols.meta'
data_file 'HANDLING_FILE' 'jeepb_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'jeepb_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'jeepb_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'f350worktruck_data/carcols.meta'
data_file 'HANDLING_FILE' 'f350worktruck_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'f350worktruck_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'f350worktruck_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'f350worktruck_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'hoonigan_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'hoonigan_data/carcols.meta'
data_file 'HANDLING_FILE' 'hoonigan_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'hoonigan_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'hoonigan_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'rocket1_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'rocket1_data/carcols.meta'
data_file 'HANDLING_FILE' 'rocket1_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'rocket1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'rocket1_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'WRX_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'WRX_data/carcols.meta'
data_file 'HANDLING_FILE' 'WRX_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'WRX_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'WRX_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'supra2_data/carcols.meta'
data_file 'HANDLING_FILE' 'supra2_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'supra2_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'supra2_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'supra2_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'PandeMraptor_data/carcols.meta'
data_file 'HANDLING_FILE' 'PandeMraptor_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'PandeMraptor_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'PandeMraptor_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'PandeMraptor_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'subaru_data/carcols.meta'
data_file 'HANDLING_FILE' 'subaru_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'subaru_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'subaru_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'subaru_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'wb_data/carcols.meta'
data_file 'HANDLING_FILE' 'wb_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'wb_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'wb_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'wb_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'trx_data/carcols.meta'
data_file 'HANDLING_FILE' 'trx_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'trx_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'trx_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'trx_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'truck_data/carcols.meta'
data_file 'HANDLING_FILE' 'truck_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'truck_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'truck_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'truck_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'ram_data/carcols.meta'
data_file 'HANDLING_FILE' 'ram_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'ram_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'ram_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'ram_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'sierra_data/carcols.meta'
data_file 'HANDLING_FILE' 'sierra_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'sierra_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'sierra_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sierra_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'hd_data/carcols.meta'
data_file 'HANDLING_FILE' 'hd_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'hd_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'hd_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'hd_data/carvariations.meta'

data_file 'CARCOLS_FILE' '20ram_data/carcols.meta'
data_file 'HANDLING_FILE' '20ram_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '20ram_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '20ram_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '20ram_data/carvariations.meta'

data_file 'CARCOLS_FILE' '21tahoe_data/carcols.meta'
data_file 'HANDLING_FILE' '21tahoe_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '21tahoe_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '21tahoe_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '21tahoe_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'silvarado_data/carcols.meta'
data_file 'HANDLING_FILE' 'silvarado_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'silvarado_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'silvarado_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'silvarado_data/carvariations.meta'

data_file 'CARCOLS_FILE' '99ram_data/carcols.meta'
data_file 'HANDLING_FILE' '99ram_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' '99ram_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' '99ram_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '99ram_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'silv_data/carcols.meta'
data_file 'HANDLING_FILE' 'silv_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'silv_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'silv_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'silv_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'ranger_data/carcols.meta'
data_file 'HANDLING_FILE' 'ranger_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'ranger_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'ranger_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'ranger_data/carvariations.meta'

data_file 'CARCOLS_FILE' 'xp_data/carcols.meta'
data_file 'HANDLING_FILE' 'xp_data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'xp_data/vehiclelayouts.meta'
data_file 'VEHICLE_METADATA_FILE' 'xp_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'xp_data/carvariations.meta'


files {
 
  '350z_data/carcols.meta',
  '350z_data/handling.meta',
  '350z_data/vehicles.meta',
  '350z_data/carvariations.meta',
  '350z_data/vehiclelayouts.meta',

  'civic_data/carcols.meta',
  'civic_data/handling.meta',
  'civic_data/vehicles.meta',
  'civic_data/carvariations.meta',
  'civic_data/vehiclelayouts.meta',

  'e46_data/carcols.meta',
  'e46_data/handling.meta',
  'e46_data/vehicles.meta',
  'e46_data/carvariations.meta',
  'e46_data/vehiclelayouts.meta',

  'evo_data/carcols.meta',
  'evo_data/handling.meta',
  'evo_data/vehicles.meta',
  'evo_data/carvariations.meta',
  'evo_data/vehiclelayouts.meta',

  'evoz_data/carcols.meta',
  'evoz_data/handling.meta',
  'evoz_data/vehicles.meta',
  'evoz_data/carvariations.meta',
  'evoz_data/vehiclelayouts.meta',

  'faf_data/carcols.meta',
  'faf_data/handling.meta',
  'faf_data/vehicles.meta',
  'faf_data/carvariations.meta',
  'faf_data/vehiclelayouts.meta',

  'golf_data/carcols.meta',
  'golf_data/handling.meta',
  'golf_data/vehicles.meta',
  'golf_data/carvariations.meta',
  'golf_data/vehiclelayouts.meta',

  'gt86_data/carcols.meta',
  'gt86_data/handling.meta',
  'gt86_data/vehicles.meta',
  'gt86_data/carvariations.meta',
  'gt86_data/vehiclelayouts.meta',

  'm3_data/carcols.meta',
  'm3_data/handling.meta',
  'm3_data/vehicles.meta',
  'm3_data/carvariations.meta',
  'm3_data/vehiclelayouts.meta',

  'rx7_data/carcols.meta',
  'rx7_data/handling.meta',
  'rx7_data/vehicles.meta',
  'rx7_data/carvariations.meta',
  'rx7_data/vehiclelayouts.meta',

  'silvia_data/carcols.meta',
  'silvia_data/handling.meta',
  'silvia_data/vehicles.meta',
  'silvia_data/carvariations.meta',
  'silvia_data/vehiclelayouts.meta',

  'skyline_data/carcols.meta',
  'skyline_data/handling.meta',
  'skyline_data/vehicles.meta',
  'skyline_data/carvariations.meta',
  'skyline_data/vehiclelayouts.meta',

  'skyline1_data/carcols.meta',
  'skyline1_data/handling.meta',
  'skyline1_data/vehicles.meta',
  'skyline1_data/carvariations.meta',
  'skyline1_data/vehiclelayouts.meta',

  'sti_data/carcols.meta',
  'sti_data/handling.meta',
  'sti_data/vehicles.meta',
  'sti_data/carvariations.meta',
  'sti_data/vehiclelayouts.meta',

  'supra_data/carcols.meta',
  'supra_data/handling.meta',
  'supra_data/vehicles.meta',
  'supra_data/carvariations.meta',
  'supra_data/vehiclelayouts.meta',

  'supra1_data/carcols.meta',
  'supra1_data/handling.meta',
  'supra1_data/vehicles.meta',
  'supra1_data/carvariations.meta',
  'supra1_data/vehiclelayouts.meta',

  'zen_data/carcols.meta',
  'zen_data/handling.meta',
  'zen_data/vehicles.meta',
  'zen_data/carvariations.meta',
  'zen_data/vehiclelayouts.meta',

  'bad_data/carcols.meta',
  'bad_data/handling.meta',
  'bad_data/vehicles.meta',
  'bad_data/carvariations.meta',
  'bad_data/vehiclelayouts.meta',

  'clean_data/carcols.meta',
  'clean_data/handling.meta',
  'clean_data/vehicles.meta',
  'clean_data/carvariations.meta',
  'clean_data/vehiclelayouts.meta',

  'drift_data/carcols.meta',
  'drift_data/handling.meta',
  'drift_data/vehicles.meta',
  'drift_data/carvariations.meta',
  'drift_data/vehiclelayouts.meta',

  'fast_data/carcols.meta',
  'fast_data/handling.meta',
  'fast_data/vehicles.meta',
  'fast_data/carvariations.meta',
  'fast_data/vehiclelayouts.meta',

  'power_data/carcols.meta',
  'power_data/handling.meta',
  'power_data/vehicles.meta',
  'power_data/carvariations.meta',
  'power_data/vehiclelayouts.meta',

  'rocket_data/carcols.meta',
  'rocket_data/handling.meta',
  'rocket_data/vehicles.meta',
  'rocket_data/carvariations.meta',
  'rocket_data/vehiclelayouts.meta',

  'nissan_data/carcols.meta',
  'nissan_data/handling.meta',
  'nissan_data/vehicles.meta',
  'nissan_data/carvariations.meta',
  'nissan_data/vehiclelayouts.meta',

  'camaro_data/carcols.meta',
  'camaro_data/handling.meta',
  'camaro_data/vehicles.meta',
  'camaro_data/carvariations.meta',
  'camaro_data/vehiclelayouts.meta',

  'gtr50_data/carcols.meta',
  'gtr50_data/handling.meta',
  'gtr50_data/vehicles.meta',
  'gtr50_data/carvariations.meta',
  'gtr50_data/vehiclelayouts.meta',

  'i8_data/carcols.meta',
  'i8_data/handling.meta',
  'i8_data/vehicles.meta',
  'i8_data/carvariations.meta',
  'i8_data/vehiclelayouts.meta',

  'lfa_data/carcols.meta',
  'lfa_data/handling.meta',
  'lfa_data/vehicles.meta',
  'lfa_data/carvariations.meta',
  'lfa_data/vehiclelayouts.meta',

  'supra3_data/carcols.meta',
  'supra3_data/handling.meta',
  'supra3_data/vehicles.meta',
  'supra3_data/carvariations.meta',
  'supra3_data/vehiclelayouts.meta',

  '350p_data/carcols.meta',
  '350p_data/handling.meta',
  '350p_data/vehicles.meta',
  '350p_data/carvariations.meta',
  '350p_data/vehiclelayouts.meta',

  'hevo_data/carcols.meta',
  'hevo_data/handling.meta',
  'hevo_data/vehicles.meta',
  'hevo_data/carvariations.meta',
  'hevo_data/vehiclelayouts.meta',

  '1969_data/carcols.meta',
  '1969_data/handling.meta',
  '1969_data/vehicles.meta',
  '1969_data/carvariations.meta',
  '1969_data/vehiclelayouts.meta',

  'impreza_data/carcols.meta',
  'impreza_data/handling.meta',
  'impreza_data/vehicles.meta',
  'impreza_data/carvariations.meta',
  'impreza_data/vehiclelayouts.meta',

  'annis_data/carcols.meta',
  'annis_data/handling.meta',
  'annis_data/vehicles.meta',
  'annis_data/carvariations.meta',
  'annis_data/vehiclelayouts.meta',

  'silv_data/carcols.meta',
  'silv_data/handling.meta',
  'silv_data/vehicles.meta',
  'silv_data/carvariations.meta',
  'silv_data/vehiclelayouts.meta',

  'ford_data/carcols.meta',
  'ford_data/handling.meta',
  'ford_data/vehicles.meta',
  'ford_data/carvariations.meta',
  'ford_data/vehiclelayouts.meta',

  'lc500_data/carcols.meta',
  'lc500_data/handling.meta',
  'lc500_data/vehicles.meta',
  'lc500_data/carvariations.meta',
  'lc500_data/vehiclelayouts.meta',

  'gpr_data/carcols.meta',
  'gpr_data/handling.meta',
  'gpr_data/vehicles.meta',
  'gpr_data/carvariations.meta',
  'gpr_data/vehiclelayouts.meta',

  'cook_data/carcols.meta',
  'cook_data/handling.meta',
  'cook_data/vehicles.meta',
  'cook_data/carvariations.meta',
  'cook_data/vehiclelayouts.meta',

  'mor_data/carcols.meta',
  'mor_data/handling.meta',
  'mor_data/vehicles.meta',
  'mor_data/carvariations.meta',
  'mor_data/vehiclelayouts.meta',

  'srt_data/carcols.meta',
  'srt_data/handling.meta',
  'srt_data/vehicles.meta',
  'srt_data/carvariations.meta',
  'srt_data/vehiclelayouts.meta',

  'pol_data/carcols.meta',
  'pol_data/handling.meta',
  'pol_data/vehicles.meta',
  'pol_data/carvariations.meta',
  'pol_data/vehiclelayouts.meta',

  'jeep_data/carcols.meta',
  'jeep_data/handling.meta',
  'jeep_data/vehicles.meta',
  'jeep_data/carvariations.meta',
  'jeep_data/vehiclelayouts.meta',

  '240_data/carcols.meta',
  '240_data/handling.meta',
  '240_data/vehicles.meta',
  '240_data/carvariations.meta',
  '240_data/vehiclelayouts.meta',

  'i8d_data/carcols.meta',
  'i8d_data/handling.meta',
  'i8d_data/vehicles.meta',
  'i8d_data/carvariations.meta',
  'i8d_data/vehiclelayouts.meta',

  'g65_data/carcols.meta',
  'g65_data/handling.meta',
  'g65_data/vehicles.meta',
  'g65_data/carvariations.meta',
  'g65_data/vehiclelayouts.meta',

  'gtr12_data/carcols.meta',
  'gtr12_data/handling.meta',
  'gtr12_data/vehicles.meta',
  'gtr12_data/carvariations.meta',
  'gtr12_data/vehiclelayouts.meta',

  'draft_data/carcols.meta',
  'draft_data/handling.meta',
  'draft_data/vehicles.meta',
  'draft_data/carvariations.meta',
  'draft_data/vehiclelayouts.meta',

  'singer_data/carcols.meta',
  'singer_data/handling.meta',
  'singer_data/vehicles.meta',
  'singer_data/carvariations.meta',
  'singer_data/vehiclelayouts.meta',

  'charger_data/carcols.meta',
  'charger_data/handling.meta',
  'charger_data/vehicles.meta',
  'charger_data/carvariations.meta',
  'charger_data/vehiclelayouts.meta',

  'c8_data/carcols.meta',
  'c8_data/handling.meta',
  'c8_data/vehicles.meta',
  'c8_data/carvariations.meta',
  'c8_data/vehiclelayouts.meta',

  'sky_data/carcols.meta',
  'sky_data/handling.meta',
  'sky_data/vehicles.meta',
  'sky_data/carvariations.meta',
  'sky_data/vehiclelayouts.meta',

  'pw_data/carcols.meta',
  'pw_data/handling.meta',
  'pw_data/vehicles.meta',
  'pw_data/carvariations.meta',
  'pw_data/vehiclelayouts.meta',

  'm5_data/vehicles.meta',
  'm5_data/carcols.meta',
  'm5_data/carvariations.meta',
  'm5_data/handling.meta',

  'rs3_data/vehicles.meta',
  'rs3_data/carcols.meta',
  'rs3_data/carvariations.meta',
  'rs3_data/handling.meta',

  'rs6_data/vehicles.meta',
  'rs6_data/carcols.meta',
  'rs6_data/carvariations.meta',
  'rs6_data/handling.meta',

  'explorer_data/vehicles.meta',
  'explorer_data/carcols.meta',
  'explorer_data/carvariations.meta',
  'explorer_data/handling.meta',
  'explorer_data/vehiclelayouts.meta',

  'charger1_data/vehiclelayouts.meta',
  'charger1_data/carcols.meta',
  'charger1_data/handling.meta',
  'charger1_data/vehicles.meta',
  'charger1_data/carvariations.meta',

  'tahoe_data/vehiclelayouts.meta',
  'tahoe_data/carcols.meta',
  'tahoe_data/handling.meta',
  'tahoe_data/vehicles.meta',
  'tahoe_data/carvariations.meta',

  'testercar_data/vehiclelayouts.meta',
  'testercar_data/carcols.meta',
  'testercar_data/handling.meta',
  'testercar_data/vehicles.meta',
  'testercar_data/carvariations.meta',

  'semaf450_data/vehiclelayouts.meta',
  'semaf450_data/carcols.meta',
  'semaf450_data/handling.meta',
  'semaf450_data/vehicles.meta',
  'semaf450_data/carvariations.meta',

  'RR_data/vehiclelayouts.meta',
  'RR_data/carcols.meta',
  'RR_data/handling.meta',
  'RR_data/vehicles.meta',
  'RR_data/carvariations.meta',

  'gt861_data/vehiclelayouts.meta',
  'gt861_data/carcols.meta',
  'gt861_data/handling.meta',
  'gt861_data/vehicles.meta',
  'gt861_data/carvariations.meta',

  'lexus_data/vehiclelayouts.meta',
  'lexus_data/carcols.meta',
  'lexus_data/handling.meta',
  'lexus_data/vehicles.meta',
  'lexus_data/carvariations.meta',

  'faf1_data/carcols.meta',
  'faf1_data/handling.meta',
  'faf1_data/vehicles.meta',
  'faf1_data/carvariations.meta',
  'faf1_data/vehiclelayouts.meta',

  'rx71_data/carcols.meta',
  'rx71_data/handling.meta',
  'rx71_data/vehicles.meta',
  'rx71_data/carvariations.meta',
  'rx71_data/vehiclelayouts.meta',

  'AT_data/carcols.meta',
  'AT_data/handling.meta',
  'AT_data/vehicles.meta',
  'AT_data/carvariations.meta',
  'AT_data/vehiclelayouts.meta',

  'cori_data/carcols.meta',
  'cori_data/handling.meta',
  'cori_data/vehicles.meta',
  'cori_data/carvariations.meta',
  'cori_data/vehiclelayouts.meta',

  'tool_data/carcols.meta',
  'tool_data/handling.meta',
  'tool_data/vehicles.meta',
  'tool_data/carvariations.meta',
  'tool_data/vehiclelayouts.meta',

  'jeepb_data/vehiclelayouts.meta',
  'jeepb_data/carcols.meta',
  'jeepb_data/handling.meta',
  'jeepb_data/vehicles.meta',
  'jeepb_data/carvariations.meta',

  'f350worktruck_data/carcols.meta',
  'f350worktruck_data/handling.meta',
  'f350worktruck_data/vehicles.meta',
  'f350worktruck_data/carvariations.meta',
  'f350worktruck_data/vehiclelayouts.meta',

  'hoonigan_data/vehiclelayouts.meta',
  'hoonigan_data/carcols.meta',
  'hoonigan_data/handling.meta',
  'hoonigan_data/vehicles.meta',
  'hoonigan_data/carvariations.meta',

  'rocket1_data/vehiclelayouts.meta',
  'rocket1_data/carcols.meta',
  'rocket1_data/handling.meta',
  'rocket1_data/vehicles.meta',
  'rocket1_data/carvariations.meta',

  'WRX_data/vehiclelayouts.meta',
  'WRX_data/carcols.meta',
  'WRX_data/handling.meta',
  'WRX_data/vehicles.meta',
  'WRX_data/carvariations.meta',

  'supra2_data/carcols.meta',
  'supra2_data/handling.meta',
  'supra2_data/vehicles.meta',
  'supra2_data/carvariations.meta',
  'supra2_data/vehiclelayouts.meta',

  'PandeMraptor_data/carcols.meta',
  'PandeMraptor_data/handling.meta',
  'PandeMraptor_data/vehicles.meta',
  'PandeMraptor_data/carvariations.meta',
  'PandeMraptor_data/vehiclelayouts.meta',

  'subaru_data/carcols.meta',
  'subaru_data/handling.meta',
  'subaru_data/vehicles.meta',
  'subaru_data/carvariations.meta',
  'subaru_data/vehiclelayouts.meta',

  'wb_data/carcols.meta',
  'wb_data/handling.meta',
  'wb_data/vehicles.meta',
  'wb_data/carvariations.meta',
  'wb_data/vehiclelayouts.meta',

  'trx_data/carcols.meta',
  'trx_data/handling.meta',
  'trx_data/vehicles.meta',
  'trx_data/carvariations.meta',
  'trx_data/vehiclelayouts.meta',

  'truck_data/carcols.meta',
  'truck_data/handling.meta',
  'truck_data/vehicles.meta',
  'truck_data/carvariations.meta',
  'truck_data/vehiclelayouts.meta',

  'ram_data/carcols.meta',
  'ram_data/handling.meta',
  'ram_data/vehicles.meta',
  'ram_data/carvariations.meta',
  'ram_data/vehiclelayouts.meta',
        
  'sierra_data/carcols.meta',
  'sierra_data/handling.meta',
  'sierra_data/vehicles.meta',
  'sierra_data/carvariations.meta',
  'sierra_data/vehiclelayouts.meta',

  'hd_data/carcols.meta',
  'hd_data/handling.meta',
  'hd_data/vehicles.meta',
  'hd_data/carvariations.meta',
  'hd_data/vehiclelayouts.meta',

  '20ram_data/carcols.meta',
  '20ram_data/handling.meta',
  '20ram_data/vehicles.meta',
  '20ram_data/carvariations.meta',
  '20ram_data/vehiclelayouts.meta',

  '21tahoe_data/carcols.meta',
  '21tahoe_data/handling.meta',
  '21tahoe_data/vehicles.meta',
  '21tahoe_data/carvariations.meta',
  '21tahoe_data/vehiclelayouts.meta',

  'silvarado_data/carcols.meta',
  'silvarado_data/handling.meta',
  'silvarado_data/vehicles.meta',
  'silvarado_data/carvariations.meta',
  'silvarado_data/vehiclelayouts.meta',

  '99ram_data/carcols.meta',
  '99ram_data/handling.meta',
  '99ram_data/vehicles.meta',
  '99ram_data/carvariations.meta',
  '99ram_data/vehiclelayouts.meta',

  'silv_data/carcols.meta',
  'silv_data/handling.meta',
  'silv_data/vehicles.meta',
  'silv_data/carvariations.meta',
  'silv_data/vehiclelayouts.meta',

  'ranger_data/carcols.meta',
  'ranger_data/handling.meta',
  'ranger_data/vehicles.meta',
  'ranger_data/carvariations.meta',
  'ranger_data/vehiclelayouts.meta',

  'xp_data/carcols.meta',
  'xp_data/handling.meta',
  'xp_data/vehicles.meta',
  'xp_data/carvariations.meta',
  'xp_data/vehiclelayouts.meta',

}



