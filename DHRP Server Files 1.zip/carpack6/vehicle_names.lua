function AddTextEntry(key, value)
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)
end

Citizen.CreateThread(function()
    AddTextEntry('94streetgt', 'Drag Mustang') --1
    AddTextEntry('alphagtr', 'Drag GTR') --2
    AddTextEntry('bmwm8', 'BMW M8') --3
    AddTextEntry('chr20', 'Widebody Charger') --4
    AddTextEntry('dodgedrag', 'Dodge Demon Drag') --5
    AddTextEntry('gdaq50', '2020 inffinity') --6
    AddTextEntry('gencoupe', 'Genesis') --7
    AddTextEntry('mache', '2020 mustang') --9
    AddTextEntry('madwbmustang', 'Widebody Mustang Drift') --10
    AddTextEntry('rmodjeep', 'Widebody Jeep') --11
    AddTextEntry('rmodlego1', 'Lego Bugatti') --12
    AddTextEntry('bentayga17', 'Prezi bentayga') --13
    AddTextEntry('streetz28', 'Street Drag') --14
    AddTextEntry('tylorz', 'Pinkable GTR') --15
    AddTextEntry('bpursport', 'Bugatti Chiron') --16
    AddTextEntry('uzigtr', 'Uzis GTR') --17
    AddTextEntry('16charger', '16 Charger') --18
    AddTextEntry('1n350z', 'Nissan 350z Nismo') --19
    AddTextEntry('rmodzl1', 'WideBody Camaro') --20
    AddTextEntry('rmodlego2', 'Lego Ferrari') --21
    AddTextEntry('rmodmartin', 'Rmod Martin') --22
    AddTextEntry('rmodlego3', 'Rmod Lego Mini') --22
    AddTextEntry('tm', 'Christmas') --22
    AddTextEntry('rmodchiron300', 'Bugatti Chiron 300') --23
    AddTextEntry('hachurac', 'Hachurac') --24
    AddTextEntry('tampax', 'Tampa X') --25
    AddTextEntry('h2m', 'H2M') --26
    AddTextEntry('rmodskyline34', 'PaulWalkers GTR Skyline') --27
    AddTextEntry('blueanti', 'Anti Personal GTR') --28
    AddTextEntry('70coronet', 'Miami Gang Car') --29
    AddTextEntry('eb110', 'eb110') --30
    AddTextEntry('evantram', 'evantram') --31
    AddTextEntry('g63amg6x6', 'g63amg6x6') --32
    AddTextEntry('radiantvff', 'radiantvff') --33
    AddTextEntry('dodgeEMS', 'Dodge Charger EMS') --34
    AddTextEntry('rmodf40', 'Ferrari F40') --35
    AddTextEntry('rmodbolide', 'Bugatti Bolide') --36
    AddTextEntry('rmodm5e34', 'BMW M5E34') --37
    AddTextEntry('rmod69police', '69 Police Charger') --38
    AddTextEntry('rmodmk7', 'HatchBack MK7') --39
    AddTextEntry('rmodbacalar', 'Bacalar') --40
    AddTextEntry('1nrx7', 'RX7') --41
    AddTextEntry('teslaxx', 'Tesla x') --42
    AddTextEntry('granlb', 'Ferrari LW') --43
    AddTextEntry('sto', 'Lambo STO') --44
    AddTextEntry('lc500', 'lexus 1c500') --45
    AddTextEntry('SupraKezi', 'Kezi Supra') --46
    AddTextEntry('m4comp', 'BMWM4') --47
    AddTextEntry('bearcat', 'SwatTruck') --48
    AddTextEntry('alphagtr', 'Drag GTR') --49
    AddTextEntry('rs6c8', 'Audi rs6c8') --50
    AddTextEntry('chgangcar', 'CH Gang Car') --51
    AddTextEntry('p1lm', 'P1 Gang Car') --52
    AddTextEntry('rmodzl1', 'CamaroWideBody') --53
    AddTextEntry('rmodrs7', 'DomsCar') --54
    AddTextEntry('fxho', 'Boat') --55

end)
