Config = {}
Config.Location = vector3(-74.51, -819.44, 326.18)
Config.ExitLocation = vector3(118.34, -1947.61, 20.75)
Config.Size = 6.0
Config.AllowedGroups = {
    "mod",
    "admin",
    "superadmin",
}