ESX = nil
inJail = false
Citizen.CreateThread(function()
	print("OK")
	while ESX == nil do 
		print("OK")
		TriggerEvent("esx:getSharedObject", function(data) ESX = data end)
		Citizen.Wait(0)
	end
end)

function OnJailed()
end

function OnUnjailed()
	local ped = PlayerPedId()
	SetEntityCoords(ped, Config.ExitLocation.x, Config.ExitLocation.y, Config.ExitLocation.z, 0.0, 0.0, 0.0, false)
end

RegisterNetEvent("admin-jail:jailPlayer")
AddEventHandler("admin-jail:jailPlayer", function(time)
	if (not inJail) then
		inJail = true
		Citizen.CreateThread(function()
			for i=1, time do 
				ESX.ShowNotification("You have " .. time - i .. " minute(s) left in your sentence.")
				for j=1, 60 do
					Citizen.Wait(1000)
				end
			end
			inJail = false
		end)
		Citizen.CreateThread(function()
			while inJail do 
				Citizen.Wait(0)
				local ped = PlayerPedId()
				local dist = #(GetEntityCoords(ped) - Config.Location)
				if (dist > Config.Size) then 
					SetEntityCoords(ped, Config.Location.x, Config.Location.y, Config.Location.z, 0.0, 0.0, 0.0, false)
					DetachEntity(ped, true, true)
				end
				DisablePlayerFiring(PlayerId(), true)
			end
			OnUnjailed()
		end)
	end
end)

RegisterNetEvent("admin-jail:unJailPlayer")
AddEventHandler("admin-jail:unJailPlayer", function(time)
	inJail = false
end)