function AddTextEntry(key, value)
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)
end

Citizen.CreateThread(function()

	AddTextEntry("dodgeEMS", "EMS Dodge")  --1
	AddTextEntry("qrv", "EMS Explorer") --2
    AddTextEntry("alstahoe", "EMS Tahoe") --3
end)
