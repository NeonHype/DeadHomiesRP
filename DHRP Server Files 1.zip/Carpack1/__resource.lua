resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'
client_script 'vehicle_names.lua'

files {
	'adam_data/vehiclelayouts.meta',
        'adam_data/carcols.meta',
        'adam_data/handling.meta',
        'adam_data/vehicles.meta',
        'adam_data/carvariations.meta',

	'sprinter211_data/vehiclelayouts.meta',
        'sprinter211_data/carcols.meta',
        'sprinter211_data/handling.meta',
        'sprinter211_data/vehicles.meta',
        'sprinter211_data/carvariations.meta',

	'infinity_data/vehiclelayouts.meta',
        'infinity_data/carcols.meta',
        'infinity_data/handling.meta',
        'infinity_data/vehicles.meta',
        'infinity_data/carvariations.meta',

	'benz_data/vehiclelayouts.meta',
        'benz_data/carcols.meta',
        'benz_data/handling.meta',
        'benz_data/vehicles.meta',
        'benz_data/carvariations.meta',

        '1999_data/vehiclelayouts.meta',
        '1999_data/carcols.meta',
        '1999_data/handling.meta',
        '1999_data/vehicles.meta',
        '1999_data/carvariations.meta',

        'chrysler_data/vehiclelayouts.meta',
        'chrysler_data/carcols.meta',
        'chrysler_data/handling.meta',
        'chrysler_data/vehicles.meta',
        'chrysler_data/carvariations.meta',

        'amels200_data/vehiclelayouts.meta',
        'amels200_data/carcols.meta',
        'amels200_data/handling.meta',
        'amels200_data/vehicles.meta',
        'amels200_data/carvariations.meta',

        'euro_data/vehiclelayouts.meta',
        'euro_data/carcols.meta',
        'euro_data/handling.meta',
        'euro_data/vehicles.meta',
        'euro_data/carvariations.meta',



  'charger_data/vehiclelayouts.meta',
  'charger_data/carcols.meta',
  'charger_data/handling.meta',
  'charger_data/vehicles.meta',
  'charger_data/carvariations.meta',

  'pdexplorer_data/vehiclelayouts.meta',
  'pdexplorer_data/carcols.meta',
  'pdexplorer_data/handling.meta',
  'pdexplorer_data/vehicles.meta',
  'pdexplorer_data/carvariations.meta',

  '21f150_data/vehiclelayouts.meta',
  '21f150_data/carcols.meta',
  '21f150_data/handling.meta',
  '21f150_data/vehicles.meta',
  '21f150_data/carvariations.meta',

  'fastback_data/vehiclelayouts.meta',
  'fastback_data/carcols.meta',
  'fastback_data/handling.meta',
  'fastback_data/vehicles.meta',
  'fastback_data/carvariations.meta', 

  'gurkhaff_data/vehiclelayouts.meta',
  'gurkhaff_data/carcols.meta',
  'gurkhaff_data/handling.meta',
  'gurkhaff_data/vehicles.meta',
  'gurkhaff_data/carvariations.meta',

  'charger1_data/vehiclelayouts.meta',
  'charger1_data/carcols.meta',
  'charger1_data/handling.meta',
  'charger1_data/vehicles.meta',
  'charger1_data/carvariations.meta',

  'pdraptor_data/vehiclelayouts.meta',
  'pdraptor_data/carcols.meta',
  'pdraptor_data/handling.meta',
  'pdraptor_data/vehicles.meta',
  'pdraptor_data/carvariations.meta',

  'pdmsutang_data/vehiclelayouts.meta',
  'pdmustang_data/carcols.meta',
  'pdmustang_data/handling.meta',
  'pdmustang_data/vehicles.meta',
  'pdmustang_data/carvariations.meta',

  'pdbugatti_data/vehiclelayouts.meta',
  'pdbugatti_data/carcols.meta',
  'pdbugatti_data/handling.meta',
  'pdbugatti_data/vehicles.meta',
  'pdbugatti_data/carvariations.meta',

  'pdk_data/vehiclelayouts.meta',
  'pdk_data/carcols.meta',
  'pdk_data/handling.meta',
  'pdk_data/vehicles.meta',
  'pdk_data/carvariations.meta',

  'pdviper_data/vehiclelayouts.meta',
  'pdviper_data/carcols.meta',
  'pdviper_data/handling.meta',
  'pdviper_data/vehicles.meta',
  'pdviper_data/carvariations.meta',

  'pddivo_data/vehiclelayouts.meta',
  'pddivo_data/carcols.meta',
  'pddivo_data/handling.meta',
  'pddivo_data/vehicles.meta',
  'pddivo_data/carvariations.meta',

  'pdcorvette_data/vehiclelayouts.meta',
  'pdcorvette_data/carcols.meta',
  'pdcorvette_data/handling.meta',
  'pdcorvette_data/vehicles.meta',
  'pdcorvette_data/carvariations.meta',

  'pdcamaro1_data/vehiclelayouts.meta',
  'pdcamaro1_data/carcols.meta',
  'pdcamaro1_data/handling.meta',
  'pdcamaro1_data/vehicles.meta',
  'pdcamaro1_data/carvariations.meta',

  'pdgtr_data/vehiclelayouts.meta',
  'pdgtr_data/carcols.meta',
  'pdgtr_data/handling.meta',
  'pdgtr_data/vehicles.meta',
  'pdgtr_data/carvariations.meta',

  '15sub_data/vehiclelayouts.meta',
  '15sub_data/carcols.meta',
  '15sub_data/handling.meta',
  '15sub_data/vehicles.meta',
  '15sub_data/carvariations.meta',

  'mach1blue_data/vehiclelayouts.meta',
  'mach1blue_data/carcols.meta',
  'mach1blue_data/handling.meta',
  'mach1blue_data/vehicles.meta',
  'mach1blue_data/carvariations.meta',

  '2020ram_data/vehiclelayouts.meta',
  '2020ram_data/carcols.meta',
  '2020ram_data/handling.meta',
  '2020ram_data/vehicles.meta',
  '2020ram_data/carvariations.meta',

  'pdtahoe_data/vehiclelayouts.meta',
  'pdtahoe_data/carcols.meta',
  'pdtahoe_data/handling.meta',
  'pdtahoe_data/vehicles.meta',
  'pdtahoe_data/carvariations.meta',

  'pdproto_data/vehiclelayouts.meta',
  'pdproto_data/carcols.meta',
  'pdproto_data/handling.meta',
  'pdproto_data/vehicles.meta',
  'pdproto_data/carvariations.meta',

  'uctahoe_data/vehiclelayouts.meta',
  'uctahoe_data/carcols.meta',
  'uctahoe_data/handling.meta',
  'uctahoe_data/vehicles.meta',
  'uctahoe_data/carvariations.meta',

  'srt2018_data/vehiclelayouts.meta',
  'srt2018_data/carcols.meta',
  'srt2018_data/handling.meta',
  'srt2018_data/vehicles.meta',
  'srt2018_data/carvariations.meta',

  '20x5m_data/vehiclelayouts.meta',
  '20x5m_data/carcols.meta',
  '20x5m_data/handling.meta',
  '20x5m_data/vehicles.meta',
  '20x5m_data/carvariations.meta',

  'sls_data/vehiclelayouts.meta',
  'sls_data/carcols.meta',
  'sls_data/handling.meta',
  'sls_data/vehicles.meta',
  'sls_data/carvariations.meta',

  'sclkuz_data/vehiclelayouts.meta',
  'sclkuz_data/carcols.meta',
  'sclkuz_data/handling.meta',
  'sclkuz_data/vehicles.meta',
  'sclkuz_data/carvariations.meta',

  'bmwm3_data/vehiclelayouts.meta',
  'bmwm3_data/carcols.meta',
  'bmwm3_data/handling.meta',
  'bmwm3_data/vehicles.meta',
  'bmwm3_data/carvariations.meta',

  'gl63_data/vehiclelayouts.meta',
  'gl63_data/carcols.meta',
  'gl63_data/handling.meta',
  'gl63_data/vehicles.meta',
  'gl63_data/carvariations.meta',

  'gemballa_data/vehiclelayouts.meta',
  'gemballa_data/carcols.meta',
  'gemballa_data/handling.meta',
  'gemballa_data/vehicles.meta',
  'gemballa_data/carvariations.meta',

  'bbentayga_data/vehiclelayouts.meta',
  'bbentayga_data/carcols.meta',
  'bbentayga_data/handling.meta',
  'bbentayga_data/vehicles.meta',
  'bbentayga_data/carvariations.meta',

  'S63AMG_data/vehiclelayouts.meta',
  'S63AMG_data/carcols.meta',
  'S63AMG_data/handling.meta',
  'S63AMG_data/vehicles.meta',
  'S63AMG_data/carvariations.meta',

  'blackghost_data/vehiclelayouts.meta',
  'blackghost_data/carcols.meta',
  'blackghost_data/handling.meta',
  'blackghost_data/vehicles.meta',
  'blackghost_data/carvariations.meta',

  'glecoupe2020_data/vehiclelayouts.meta',
  'glecoupe2020_data/carcols.meta',
  'glecoupe2020_data/handling.meta',
  'glecoupe2020_data/vehicles.meta',
  'glecoupe2020_data/carvariations.meta',

  '16CC_data/vehiclelayouts.meta',
  '16CC_data/carcols.meta',
  '16CC_data/handling.meta',
  '16CC_data/vehicles.meta',
  '16CC_data/carvariations.meta',

  'escalade_data/vehiclelayouts.meta',
  'escalade_data/carcols.meta',
  'escalade_data/handling.meta',
  'escalade_data/vehicles.meta',
  'escalade_data/carvariations.meta',

  'gle_data/vehiclelayouts.meta',
  'gle_data/carcols.meta',
  'gle_data/handling.meta',
  'gle_data/vehicles.meta',
  'gle_data/carvariations.meta',

  'ctsv16_data/vehiclelayouts.meta',
  'ctsv16_data/carcols.meta',
  'ctsv16_data/handling.meta',
  'ctsv16_data/vehicles.meta',
  'ctsv16_data/carvariations.meta',

  'W900_data/vehiclelayouts.meta',
  'W900_data/carcols.meta',
  'W900_data/handling.meta',
  'W900_data/vehicles.meta',
  'W900_data/carvariations.meta',

  'monte_data/vehiclelayouts.meta',
  'monte_data/carcols.meta',
  'monte_data/handling.meta',
  'monte_data/vehicles.meta',
  'monte_data/carvariations.meta',

  '21durango_data/vehiclelayouts.meta',
  '21durango_data/carcols.meta',
  '21durango_data/handling.meta',
  '21durango_data/vehicles.meta',
  '21durango_data/carvariations.meta',

  'vclass_data/vehiclelayouts.meta',
  'vclass_data/carcols.meta',
  'vclass_data/handling.meta',
  'vclass_data/vehicles.meta',
  'vclass_data/carvariations.meta',

  'bcrzrxp_data/vehiclelayouts.meta',
  'bcrzrxp_data/carcols.meta',
  'bcrzrxp_data/handling.meta',
  'bcrzrxp_data/vehicles.meta',
  'bcrzrxp_data/carvariations.meta',

  'easyrider_data/vehiclelayouts.meta',
  'easyrider_data/carcols.meta',
  'easyrider_data/handling.meta',
  'easyrider_data/vehicles.meta',
  'easyrider_data/carvariations.meta',

  'gsxr19_data/vehiclelayouts.meta',
  'gsxr19_data/carcols.meta',
  'gsxr19_data/handling.meta',
  'gsxr19_data/vehicles.meta',
  'gsxr19_data/carvariations.meta',

  'gsxr1000_data/vehiclelayouts.meta',
  'gsxr1000_data/carcols.meta',
  'gsxr1000_data/handling.meta',
  'gsxr1000_data/vehicles.meta',
  'gsxr1000_data/carvariations.meta',

  'hayabusadrag_data/vehiclelayouts.meta',
  'hayabusadrag_data/carcols.meta',
  'hayabusadrag_data/handling.meta',
  'hayabusadrag_data/vehicles.meta',
  'hayabusadrag_data/carvariations.meta',

  'na25_data/vehiclelayouts.meta',
  'na25_data/carcols.meta',
  'na25_data/handling.meta',
  'na25_data/vehicles.meta',
  'na25_data/carvariations.meta',

  'yzfr6_data/vehiclelayouts.meta',
  'yzfr6_data/carcols.meta',
  'yzfr6_data/handling.meta',
  'yzfr6_data/vehicles.meta',
  'yzfr6_data/carvariations.meta',

  'zx10r_data/vehiclelayouts.meta',
  'zx10r_data/carcols.meta',
  'zx10r_data/handling.meta',
  'zx10r_data/vehicles.meta',
  'zx10r_data/carvariations.meta',

  'a8fsi_data/vehiclelayouts.meta',
  'a8fsi_data/carcols.meta',
  'a8fsi_data/handling.meta',
  'a8fsi_data/vehicles.meta',
  'a8fsi_data/carvariations.meta',

  'sq72016_data/vehiclelayouts.meta',
  'sq72016_data/carcols.meta',
  'sq72016_data/handling.meta',
  'sq72016_data/vehicles.meta',
  'sq72016_data/carvariations.meta',

  'camry55_data/vehiclelayouts.meta',
  'camry55_data/carcols.meta',
  'camry55_data/handling.meta',
  'camry55_data/vehicles.meta',
  'camry55_data/carvariations.meta',

  'mache_data/vehiclelayouts.meta',
  'mache_data/carcols.meta',
  'mache_data/handling.meta',
  'mache_data/vehicles.meta',
  'mache_data/carvariations.meta',

  'cone_data/vehiclelayouts.meta',
  'cone_data/carcols.meta',
  'cone_data/handling.meta',
  'cone_data/vehicles.meta',
  'cone_data/carvariations.meta',

  'diavel_data/vehiclelayouts.meta',
  'diavel_data/carcols.meta',
  'diavel_data/handling.meta',
  'diavel_data/vehicles.meta',
  'diavel_data/carvariations.meta',

  'escade_data/vehiclelayouts.meta',
  'escade_data/carcols.meta',
  'escade_data/handling.meta',
  'escade_data/vehicles.meta',
  'escade_data/carvariations.meta',

  'pcs18_data/vehiclelayouts.meta',
  'pcs18_data/carcols.meta',
  'pcs18_data/handling.meta',
  'pcs18_data/vehicles.meta',
  'pcs18_data/carvariations.meta',

  'dawnonyx_data/vehiclelayouts.meta',
  'dawnonyx_data/carcols.meta',
  'dawnonyx_data/handling.meta',
  'dawnonyx_data/vehicles.meta',
  'dawnonyx_data/carvariations.meta',

  'fpace_data/vehiclelayouts.meta',
  'fpace_data/carcols.meta',
  'fpace_data/handling.meta',
  'fpace_data/vehicles.meta',
  'fpace_data/carvariations.meta',

  'c63w204_data/vehiclelayouts.meta',
  'c63w204_data/carcols.meta',
  'c63w204_data/handling.meta',
  'c63w204_data/vehicles.meta',
  'c63w204_data/carvariations.meta',

  'cls2015_data/vehiclelayouts.meta',
  'cls2015_data/carcols.meta',
  'cls2015_data/handling.meta',
  'cls2015_data/vehicles.meta',
  'cls2015_data/carvariations.meta',

  'oycmr500_data/vehiclelayouts.meta',
  'oycmr500_data/carcols.meta',
  'oycmr500_data/handling.meta',
  'oycmr500_data/vehicles.meta',
  'oycmr500_data/carvariations.meta',

  'm5e60_data/vehiclelayouts.meta',
  'm5e60_data/carcols.meta',
  'm5e60_data/handling.meta',
  'm5e60_data/vehicles.meta',
  'm5e60_data/carvariations.meta',

  'dbsr_data/vehiclelayouts.meta',
  'dbsr_data/carcols.meta',
  'dbsr_data/handling.meta',
  'dbsr_data/vehicles.meta',
  'dbsr_data/carvariations.meta',

  'mbslr_data/vehiclelayouts.meta',
  'mbslr_data/carcols.meta',
  'mbslr_data/handling.meta',
  'mbslr_data/vehicles.meta',
  'mbslr_data/carvariations.meta',

  'boxster_data/vehiclelayouts.meta',
  'boxster_data/carcols.meta',
  'boxster_data/handling.meta',
  'boxster_data/vehicles.meta',
  'boxster_data/carvariations.meta',

  'mcgt20_data/vehiclelayouts.meta',
  'mcgt20_data/carcols.meta',
  'mcgt20_data/handling.meta',
  'mcgt20_data/vehicles.meta',
  'mcgt20_data/carvariations.meta',

  'f430s_data/vehiclelayouts.meta',
  'f430s_data/carcols.meta',
  'f430s_data/handling.meta',
  'f430s_data/vehicles.meta',
  'f430s_data/carvariations.meta',

  'vxr_data/vehiclelayouts.meta',
  'vxr_data/carcols.meta',
  'vxr_data/handling.meta',
  'vxr_data/vehicles.meta',
  'vxr_data/carvariations.meta',


}

data_file 'VEHICLE_LAYOUTS_FILE' 'adam_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'adam_data/carcols.meta'
data_file 'HANDLING_FILE' 'adam_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'adam_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'adam_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'sprinter211_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'sprinter211_data/carcols.meta'
data_file 'HANDLING_FILE' 'sprinter211_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'sprinter211_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sprinter211_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'infinity_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'infinity_data/carcols.meta'
data_file 'HANDLING_FILE' 'infinity_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'infinity_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'infinity_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'benz_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'benz_data/carcols.meta'
data_file 'HANDLING_FILE' 'benz_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'benz_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'benz_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '1999_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '1999_data/carcols.meta'
data_file 'HANDLING_FILE' '1999_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '1999_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '1999_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'chrysler_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'chrysler_data/carcols.meta'
data_file 'HANDLING_FILE' 'chrysler_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'chrysler_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'chrysler_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'charger_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'charger_data/carcols.meta'
data_file 'HANDLING_FILE' 'charger_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'charger_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'charger_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdexplorer_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdexplorer_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdexplorer_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdexplorer_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdexplorer_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '21f150_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '21f150_data/carcols.meta'
data_file 'HANDLING_FILE' '21f150_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '21f150_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '21f150carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'fastback_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'fastback_data/carcols.meta'
data_file 'HANDLING_FILE' 'fastback_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'fastback_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'fastback_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gurkhaff_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gurkhaff_data/carcols.meta'
data_file 'HANDLING_FILE' 'gurkhaff_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gurkhaff_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gurkhaff_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'charger1_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'charger1_data/carcols.meta'
data_file 'HANDLING_FILE' 'charger1_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'charger1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'charger1_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdraptor_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdraptor_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdraptor_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdraptor_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdraptor_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdmustang_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdmustang_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdmustang_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdmustang_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdmusatng_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdbugatti_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdbugatti_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdbugatti_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdbugatti_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdbugatti_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdk_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdk_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdk_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdk_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdk_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdviper_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdviper_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdviper_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdviper_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdviper_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pddivo_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pddivo_data/carcols.meta'
data_file 'HANDLING_FILE' 'pddivo_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pddivo_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pddivo_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdcorvette_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdcorvette_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdcorvette_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdcorvette_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdcorvette_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdcamaro1_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdcamaro1_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdcamaro1_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdcamaro1_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdcamaro1_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdgtr_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdgtr_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdgtr_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdgtr_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdgtr_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '15sub_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '15sub_data/carcols.meta'
data_file 'HANDLING_FILE' '15sub_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '15sub_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '15sub_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'mach1blue_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'mach1blue_data/carcols.meta'
data_file 'HANDLING_FILE' 'mach1blue_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'mach1blue_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'mach1blue_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '2020ram_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '2020ram_data/carcols.meta'
data_file 'HANDLING_FILE' '2020ram_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '2020ram_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '2020ram_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdtahoe_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdtahoe_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdtahoe_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdtahoe_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdtahoe_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pdproto_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pdproto_data/carcols.meta'
data_file 'HANDLING_FILE' 'pdproto_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pdproto_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pdproto_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'uctahoe_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'uctahoe_data/carcols.meta'
data_file 'HANDLING_FILE' 'uctahoe_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'uctahoe_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'uctahoe_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'admin_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'admin_data/carcols.meta'
data_file 'HANDLING_FILE' 'admin_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'admin_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'admin_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'amels200_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'amels200_data/carcols.meta'
data_file 'HANDLING_FILE' 'amels200_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'amels200_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'amels200_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'srt2018_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'srt2018_data/carcols.meta'
data_file 'HANDLING_FILE' 'srt2018_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'srt2018_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'srt2018_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '20x5m_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '20x5m_data/carcols.meta'
data_file 'HANDLING_FILE' '20x5m_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '20x5m_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '20x5m_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'euro_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'euro_data/carcols.meta'
data_file 'HANDLING_FILE' 'euro_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'euro_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'euro_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'sls_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'sls_data/carcols.meta'
data_file 'HANDLING_FILE' 'sls_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'sls_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sls_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'sclkuz_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'sclkuz_data/carcols.meta'
data_file 'HANDLING_FILE' 'sclkuz_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'sclkuz_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sclkuz_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'bmwm3_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'bmwm3_data/carcols.meta'
data_file 'HANDLING_FILE' 'bmwm3_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'bmwm3_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'bmwm3_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gl63_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gl63_data/carcols.meta'
data_file 'HANDLING_FILE' 'gl63_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gl63_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gl63_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gemballa_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gemballa_data/carcols.meta'
data_file 'HANDLING_FILE' 'gemballa_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gemballa_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gemballa_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'bbentayga_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'bbentayga_data/carcols.meta'
data_file 'HANDLING_FILE' 'bbentayga_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'bbentayga_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'bbentayga_data/carvariations.meta'


data_file 'VEHICLE_LAYOUTS_FILE' 'S63AMG_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'S63AMG_data/carcols.meta'
data_file 'HANDLING_FILE' 'S63AMG_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'S63AMG_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'S63AMG_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'blackghost_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'blackghost_data/carcols.meta'
data_file 'HANDLING_FILE' 'blackghost_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'blackghost_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'blackghost_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'glecoupe2020_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'glecoupe2020_data/carcols.meta'
data_file 'HANDLING_FILE' 'glecoupe2020_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'glecoupe2020_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'glecoupe2020_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '16CC_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '16CC_data/carcols.meta'
data_file 'HANDLING_FILE' '16CC_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '16CC_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '16CC_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'escalade_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'escalade_data/carcols.meta'
data_file 'HANDLING_FILE' 'escalade_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'escalade_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'escalade_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gle_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gle_data/carcols.meta'
data_file 'HANDLING_FILE' 'gle_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gle_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gle_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'ctsv16_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'ctsv16_data/carcols.meta'
data_file 'HANDLING_FILE' 'ctsv16_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'ctsv16_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'ctsv16_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'W900_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'W900_data/carcols.meta'
data_file 'HANDLING_FILE' 'W900_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'W900_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'W900_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'monte_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'monte_data/carcols.meta'
data_file 'HANDLING_FILE' 'monte_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'monte_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'monte_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' '21durango_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' '21durango_data/carcols.meta'
data_file 'HANDLING_FILE' '21durango_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' '21durango_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' '21durango_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'vclass_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'vclass_data/carcols.meta'
data_file 'HANDLING_FILE' 'vclass_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'vclass_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'vclass_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'bcrzrxp_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'bcrzrxp_data/carcols.meta'
data_file 'HANDLING_FILE' 'bcrzrxp_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'bcrzrxp_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'bcrzrxp_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'easyrider_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'easyrider_data/carcols.meta'
data_file 'HANDLING_FILE' 'easyrider_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'easyrider_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'easyrider_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'vclass_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'vclass_data/carcols.meta'
data_file 'HANDLING_FILE' 'vclass_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'vclass_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'vclass_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gsxr19_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gsxr19_data/carcols.meta'
data_file 'HANDLING_FILE' 'gsxr19_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gsxr19_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gsxr19_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'gsxr1000_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'gsxr1000_data/carcols.meta'
data_file 'HANDLING_FILE' 'gsxr1000_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'gsxr1000_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'gsxr1000_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'hayabusadrag_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'hayabusadrag_data/carcols.meta'
data_file 'HANDLING_FILE' 'hayabusadrag_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'hayabusadrag_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'hayabusadrag_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'na25_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'na25_data/carcols.meta'
data_file 'HANDLING_FILE' 'na25_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'na25_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'na25_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'yzfr6_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'yzfr6_data/carcols.meta'
data_file 'HANDLING_FILE' 'yzfr6_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'yzfr6_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'yzfr6_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'zx10r_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'zx10r_data/carcols.meta'
data_file 'HANDLING_FILE' 'zx10r_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'zx10r_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'zx10r_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'a8fsi_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'a8fsi_data/carcols.meta'
data_file 'HANDLING_FILE' 'a8fsi_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'a8fsi_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'a8fsi_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'sq72016_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'sq72016_data/carcols.meta'
data_file 'HANDLING_FILE' 'sq72016_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'sq72016_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'sq72016_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'camry55_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'camry55_data/carcols.meta'
data_file 'HANDLING_FILE' 'camry55_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'camry55_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'camry55_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'mache_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'mache_data/carcols.meta'
data_file 'HANDLING_FILE' 'mache_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'mache_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'mache_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'cone_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'cone_data/carcols.meta'
data_file 'HANDLING_FILE' 'cone_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'cone_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'cone_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'diavel_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'diavel_data/carcols.meta'
data_file 'HANDLING_FILE' 'diavel_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'diavel_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'diavel_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'escade_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'escade_data/carcols.meta'
data_file 'HANDLING_FILE' 'escade_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'escade_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'escade_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'pcs18_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'pcs18_data/carcols.meta'
data_file 'HANDLING_FILE' 'pcs18_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'pcs18_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'pcs18_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'dawnonyx_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'dawnonyx_data/carcols.meta'
data_file 'HANDLING_FILE' 'dawnonyx_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'dawnonyx_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'dawnonyx_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'fpace_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'fpace_data/carcols.meta'
data_file 'HANDLING_FILE' 'fpace_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'fpace_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'fpace_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'c63w204_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'c63w204_data/carcols.meta'
data_file 'HANDLING_FILE' 'c63w204_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'c63w204_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'c63w204_dataa/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'cls2015_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'cls2015_data/carcols.meta'
data_file 'HANDLING_FILE' 'cls2015_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'cls2015_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'cls2015_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'vxr_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'vxr_data/carcols.meta'
data_file 'HANDLING_FILE' 'vxr_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'vxr_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'vxr_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'oycmr500_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'oycmr500_data/carcols.meta'
data_file 'HANDLING_FILE' 'oycmr500_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'oycmr500_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'oycmr500_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'm5e60_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'm5e60_data/carcols.meta'
data_file 'HANDLING_FILE' 'm5e60_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'm5e60_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'm5e60_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'dbsr_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'dbsr_data/carcols.meta'
data_file 'HANDLING_FILE' 'dbsr_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'dbsr_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'dbsr_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'mbslr_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'mbslr_data/carcols.meta'
data_file 'HANDLING_FILE' 'mbslr_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'mbslr_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'mbslr_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'boxster_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'boxster_data/carcols.meta'
data_file 'HANDLING_FILE' 'boxster_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'boxster_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'boxster_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'mcgt20_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'mcgt20_data/carcols.meta'
data_file 'HANDLING_FILE' 'mcgt20_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'mcgt20_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'mcgt20_data/carvariations.meta'

data_file 'VEHICLE_LAYOUTS_FILE' 'f430s_data/vehiclelayouts.meta'
data_file 'CARCOLS_FILE' 'f430s_data/carcols.meta'
data_file 'HANDLING_FILE' 'f430s_data/handling.meta'
data_file 'VEHICLE_METADATA_FILE' 'f430s_data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'f430s_data/carvariations.meta'






























