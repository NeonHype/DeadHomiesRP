ConfigCL = {}

ConfigCL.OpenMenu = 56 -- Key to Open Menu, feel free to change this.
ConfigCL.ServerName = "DeadHomiesRP" --Server Name
