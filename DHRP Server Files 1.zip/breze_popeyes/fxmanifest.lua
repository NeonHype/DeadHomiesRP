fx_version "bodacious"

games { "gta5" }

this_is_a_map "yes"

