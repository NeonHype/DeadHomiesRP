function AddTextEntry(key, value)
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), key, value)
end

Citizen.CreateThread(function()
	AddTextEntry("divo", "Bugatti Divo")  --1
	AddTextEntry("g500", "Mercedes G500") --2
    AddTextEntry("nh2r", "Ninja H2") --3
    AddTextEntry("yz450f", "Yamaha YZ450F") --4
    AddTextEntry("tmsm", "TM450 Supermoto") --5
    AddTextEntry("wraith", "Rolls Royce Wraith")  --6
    AddTextEntry("urus", "Lamborghini Urus") --7
    AddTextEntry("rmodsianr", "Lamborghini Sian") --8
    AddTextEntry("19gt500", "Ford Mustang Shelby") --9
    AddTextEntry("lamboavj", "Lamborghini Aventador SVJ")  --10
    AddTextEntry("DemonHawk", "Demonhawk")  --11
    AddTextEntry("911turbos", "Porsche 911 Turbo") --12
    AddTextEntry("MVISIONGT", "Mercedes-Benz AMG Vision GT") --13
    AddTextEntry("sv", "Lamborghini Aventador SV") --14
    AddTextEntry("GTRC", "Mercedes-Benz AMG GT-R") --15 --FOH
    AddTextEntry("SENNA", "McLaren Senna") --16
    AddTextEntry("C7", "Corvette C7") --17
    AddTextEntry("g63mg", "G63 Mansory") --18
    AddTextEntry("bug300ss", "Buggati Chiron") --19
    AddTextEntry('dawn', 'Mansory RR Dawn') --20
    AddTextEntry('rmodjesko', 'Koenigsegg Jesko') --21 
    --AddTextEntry('rmodc63amg', 'Mercedes AMG C63') --22
    AddTextEntry('TR22', 'Tesla Roadster') --23
    AddTextEntry('rm3e36', 'BMW M3 E36') --24
    AddTextEntry('370z', 'Nissan 370z') --25
    AddTextEntry('EK9', 'Honda Civic EK9') --26
    AddTextEntry('lwhuracan', 'Liberty Walk Huracan') --27
    AddTextEntry('gtr', 'Nissan GTR') --28
    AddTextEntry('SRTDAY20', 'Charger Hellcat SRT') --29
    AddTextEntry('dcd', 'Dodge Demon SRT') --30
    AddTextEntry('rmodjeep', 'Jeep Grand Cherokee') --31 
    AddTextEntry('jeep20', 'LiftedJeep') --32
    AddTextEntry('c7r', 'MA Corvette') --33
    AddTextEntry('wildtrak', 'Ford Bronco Wildtrak') --34
    AddTextEntry('lw458s', 'Cartel Ferrari') --35
    AddTextEntry('audir8lms2', 'Tsuki Audi') --36
    --AddTextEntry('alphagtr', 'Mario Drag GTR') --37
    AddTextEntry('rmodf40', 'Ferrari F40') --38 
    AddTextEntry('DragNova', 'KTM Drag Nova') --39
    AddTextEntry('Imola', 'Sebbys 1-1') --40 
    AddTextEntry('brzrbv3', 'MA BRZ') --41
    AddTextEntry('19tundra', 'Toyota Tundra') --42
    AddTextEntry('impalaf350', 'Lifted Ford F350') --43
    AddTextEntry('rmodrs6', 'Audi RS6') --44 add to shop
    AddTextEntry('rmodbacalar', 'Bentley Bacalar') --45 
    AddTextEntry('rmodmk7', 'Golf MK7 JP') --46 
    AddTextEntry('rmodm5e34', 'BMW M5 E34') --47 
    AddTextEntry('rmodcharger69', 'Dodge Charger RT69') --48
    AddTextEntry('rmodbugatti', 'MerryWeather Buggati') --49 
    AddTextEntry('rmodgtr50', 'Nissan GTR 50') --50
    AddTextEntry("durango", "SantanaWhip") --1
    AddTextEntry("jeepg", "Jeep Gladiator") --2
    AddTextEntry("LykanHypersport", "Lykan Hypersport") --3 
    AddTextEntry("lamtmc", "Lamborghini Terzo Millenio") --4
    AddTextEntry("aperta", "leferrari") --5
    AddTextEntry("vip8", "Dodge Viper") --6
    AddTextEntry("G770", "Lumma CLR G770") --7
    AddTextEntry("kev", "Cadillac ktmrider919") --8
    AddTextEntry("flhxs_streetglide_special18", "Harley ktmrider919") --9
    AddTextEntry("supra2", "Supra ktmrider919") --10
    AddTextEntry("brz", "Safari gay brz") --11
    AddTextEntry("ford30t", "Vexx Hot Rod") --12 --New
    AddTextEntry("rcf", "lexus") --13
    --AddTextEntry("s15mak", "vexx s15") --14
    --AddTextEntry("m3kean", "vexx bmw") --15 --need to add back
    AddTextEntry("dragfd", "rx7 ktmrider") --16
    AddTextEntry("m5f90", "Mints CustomCar1") --17
    AddTextEntry("918SPYDER", "Porsche 918 Spyder") --18
    AddTextEntry("bmwm8", "Mints CustomCar2") --19
    AddTextEntry("evo9", "Lancer IX") --20
    AddTextEntry("zl12017", "Camaro ZL1") --21
    AddTextEntry("er34gda", "Vexx Skyline") --22 
    AddTextEntry("17m760i", "PreziBMW") --23
    AddTextEntry("swat1", "PoliceSwat") --24
    AddTextEntry("rmodlp770", "Shun") --25
    --AddTextEntry("cateyedually", "Danny Carter Truck") --26
    AddTextEntry("pgt3", "The Simpsons Porsche") --27
    --AddTextEntry("v4sf", "Vexx Motorcycle") --28 --new
    AddTextEntry("filthynsx", "Chop NSX") --29
    --AddTextEntry("civik", "Vexx Civic") --30
    --AddTextEntry("trixbox", "Cereal Car") --31 
    AddTextEntry("velociraptor", "6x6 Truck") --32
    AddTextEntry("2020excsm", "2020 KTM") --33
    AddTextEntry("swat1", "SwatTruck") --34
    AddTextEntry("ft1gr3", "Toyota Supra") --35
    AddTextEntry("rmodf12tdf", "Ferrari F12") --36
     AddTextEntry('m4lb', 'Liberty Walk M4') --1
    AddTextEntry('mustang19', 'Ford Mustang GT') --2
    AddTextEntry('SkylineGTR', 'Skyline GTR R34') --3
    AddTextEntry('hevo', 'Lamborghini Huracan Evo') --4
    AddTextEntry('laferrari17', 'Ferrari LaFerrari') --5
    AddTextEntry('a80', 'Toyota Supra JZA') --6
    AddTextEntry('fd', 'Mazda RX7') --7
    --AddTextEntry('fd2', 'Honda Civic Type-R') --8
    AddTextEntry('r35', 'Nissan GTR R35') --9
    AddTextEntry('r32', 'Nissan GTR R32') --10
    AddTextEntry('na1', 'Honda NSX') --11
    AddTextEntry('mst', 'GT500 Mustang') --12
    AddTextEntry('r6', 'Yamaha YZF-R6') --13
    AddTextEntry('na6', 'Mazda Miata MX5') --14
    AddTextEntry('rmodi8mlb', 'Liberty Walk i8') --15
    AddTextEntry('f8t', 'Ferrari F8 Tributo') --16
    AddTextEntry('s15', 'Nissan S15') --17
    AddTextEntry('rmodamgc63', 'Mercedes-Benz AMG C63') --18
    AddTextEntry("can", "Can-Am 4x4") --19
    AddTextEntry("m3e46", "BMW M3 E46") --20
    AddTextEntry("lp700", "Lamborghini Aventador LP700") --21
    --AddTextEntry("rmodgt63", "AMG GT63") --22
    AddTextEntry("gmck", "GMC Sierra 2500 Denali") --23
    AddTextEntry("rmodrs7", "Audi RS7 Widebody") --24
    AddTextEntry("mlnovitec", "Maserati") --25
    AddTextEntry("streetsupra", "KTM Drag Supra") --26
    AddTextEntry("mansm8", "Dre BMW M8") --27
    --Start Donor Cars
    AddTextEntry("rmodbolide", "Bugatti Bolide")  --28
    AddTextEntry("rmodskyline34", "Nissan Skyline GTR-34") --35
    AddTextEntry("rmodtracktor", "Racing Tractor") --36
     AddTextEntry("rmodzl1police", "Police Camaro") --1
    AddTextEntry("2020raptor", "Raptor 2020") --2
    AddTextEntry("VettePD", "Police Corvette") --3
    AddTextEntry("CivicPDBlue","Police Civic") --4
    AddTextEntry("hellcatBLUE", "Police Hellcat Blue") --5
    AddTextEntry("hellcatRED", "Police Hellcat Red") --6
    AddTextEntry("18jeep", "2018 Jeep") --7
    AddTextEntry("polchal", "2016 Challenger") --8
    AddTextEntry("718", "Police Porsche") --9
    AddTextEntry("polf430", "Police Ferrari") --10
    AddTextEntry("polchiron", "Police Chiron") --11
    AddTextEntry("MCLAREN", "Polie McLaren") --12
    AddTextEntry("polaventa", "Police Aventador") --13
    AddTextEntry("Custom","Police Bike") --14
    AddTextEntry("2015POLSTANG", "Police Mustang") --15
    AddTextEntry("g63amg6x6cop", "Police 6x6") --16
    AddTextEntry("VEYRON", "Bugatti Veyron") --17
    AddTextEntry("umcont", "LincPD") --18
    --End Donor Cars
    
    --Start 1 of 1's

    --Start KTMRider919
    AddTextEntry("ramtis", "KTM Dodge Ram")  --1
    AddTextEntry("maliboohoo", "KTM Drag Malibu")  --2
    --AddTextEntry("placemodelnamehere", "NameOfCarHere")  --3 
    AddTextEntry("majfc", "KTM Mazda RX-7")  --4
    AddTextEntry("Charger2020", "KTM Hellcat")  --5
    AddTextEntry("titann", "KTM Nissan Titan") --21
    --End KTMRider919

    --Start Judge
    AddTextEntry("rmodlego2", "Judge Lego Ferrari")  --6
    AddTextEntry("rmodf40", "Judge Ferrari F40")  --14
    --End Judge

    --Start WAZE
    AddTextEntry("patty", "Krabby Patty Mobile")  --37
    --End WAZE

    --Start Shun
    AddTextEntry("VEYRON12", "Shun Bugatti Veyron")  --8
    AddTextEntry("j50", "Shun Ferrari") --9
    AddTextEntry("GT17", "Shun Ford GT") --10
    --End Shun

    --Start Vexx
    AddTextEntry("sultanrsv8", "Vexx Sultan") --11
    AddTextEntry("tempestax", "Vexx Tempesta") --26
    AddTextEntry("lambose", "Vexx Sesto Elemento") --27
    AddTextEntry("lambose", "Vexx Lamborghini") --16
    AddTextEntry("beck", "Vexx Beck") --17
    AddTextEntry("dodgesrt2", "Vexx Drag Truck") --29
    AddTextEntry("cw2020", "Vexx CW20") --34
    --End Vexx

    --Start Vorce
    --AddTextEntry("rmodlp570", "Vorce LP570") --12
    --End Vorce

    --Start YouSk1d
    AddTextEntry("SENTINEL", "Nissan Skyline R33") --15
    --End YouSk1d

    --Start Kurupt
    AddTextEntry("rmodlp570", "Kurupt Lamborghini Gallardo") --32
    --End Kurupt

    --End 1 of 1's

    --Start Gang Cars

    --Start The Commission
    AddTextEntry("db11", "The Commission DB11")  --23
    --End The Commissions

    --Start NF (No Forgiveness)
    AddTextEntry("rmodm4", "NF BMW M4")  --7
    --End NF (No Forgiveness)

    --Start Sniper Gang
    AddTextEntry("610DTM", "Sniper Gang Huracan")  --22
    --End Sniper Gang

    --Start Element
    AddTextEntry("variszupra", "Element Supra")  --24
    --End Element

    --Start GDK
    AddTextEntry("silvia3", "GDK Silvia S14")  --25
    --End GDK

    --Start Venom
    AddTextEntry("tampax", "Venom Tampa X")  --19
    --End Venom

    --Start BD
    AddTextEntry("hachurac", "BD Hachura")  --18
    --End BD 

    --Start Woo
    AddTextEntry("mbbs20", "Woo Benz AMG GT")  --30
    --End Woo 

    --Start Gangsta Brothahood
    AddTextEntry("vulcan", "Gangsta Brothahood Vulcan")  --31
    --End Gangsta Brothahood 

    --Start Drain Gang
    --AddTextEntry("mbbs20", "Woo Benz AMG GT")  --
    --End Drain Gang 

   

end)
